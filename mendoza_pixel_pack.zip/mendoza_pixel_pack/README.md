# MENDOZA INVADIDA — Pack de sprites pixel art

Pack original estilo indie para un juego 2D de vista lateral. Mendoza (cordillera, viñedos, álamos, acequias, casas de adobe) bajo una invasión que nadie sabe si es de extraterrestres, monstruos o zombies.

Todo está dibujado desde cero: no hay personajes ni diseños de otros juegos.

## Contenido

| Carpeta / archivo | Qué es |
|---|---|
| `spritesheet.png` + `atlas.json` | Todos los sprites en una sola hoja (256 px de ancho) con coordenadas y animaciones |
| `sprites/` | Cada sprite en su propio PNG, tamaño original (1x), por categoría |
| `backgrounds/` | 4 capas de fondo parallax, 320x176, repetibles en horizontal |
| `palette/` | Paleta de 40 colores (`.png`, `.gpl` para GIMP/Aseprite, `.hex` estilo Lospec) |
| `preview/` | Catálogo ampliado, escena de ejemplo y GIF animado |
| `source/build.py` | Script que regenera todo el pack |

## Sprites

**Personajes (16x24):** el viñatero (`player`: idle, caminar x2, disparo, golpe) y un vecino de repuesto (`vecino`) con otros colores.

**Invasores:**
- `bicho_baboso` (16x16): ¿alien o monstruo? Tiene antenas y es baboso.
- `zombi_vinatero` (16x24): un trabajador de la viña, ahora verde. Mira a la derecha; espejalo para que avance hacia la izquierda.
- `ojo_flotante` (16x16): ¿ovni u ojo gigante?
- `el_ente` (32x32, jefe): mitad ovni, mitad monstruo con dientes.
- Cada uno tiene un frame `_hit` (silueta blanca) para el destello de golpe.

**Items (16x16):** uva, botella de Malbec, empanada, mate, sifón de soda.

**Efectos:** chorro de soda (8x8, 2 frames, es el proyectil del héroe) y explosión (16x16, 4 frames).

**UI:** corazón lleno y vacío (8x8).

**Tiles (16x16):** suelo con pasto, tierra, adobe, teja, roca, roca con nieve, ruta, y agua de acequia (4 frames).

**Props:** álamo (16x48), parra con uvas, barril y casa de adobe (48x40).

**Fondos (320x176):** cielo con el portal de la invasión y ovnis (fijo, no se repite), cordillera de los Andes con nieve, sierras y viñedo con álamos.

## Animaciones (en `atlas.json`)

`player_walk` (8 fps), `vecino_walk` (6), `bicho_baboso` (4), `zombi_vinatero` (5), `ojo_flotante` (4), `el_ente` (3), `fx_chorro` (10), `fx_explosion` (12, sin loop), `tile_acequia` (4).

## Cómo usarlo

- Usá filtro **NEAREST** (sin suavizado) y escala entera (3x o 4x) para que los píxeles queden nítidos.
- Los tiles son de 16x16. Los pies de los personajes están en el borde inferior de cada sprite, así que se apoyan directo sobre el suelo.
- Para los fondos, mové cada capa a distinta velocidad: cielo (quieto), Andes (lenta), sierras (media), viñedo (rápida).
- Para las partes sin loop, como la explosión, recordá cortar la animación en el último frame.

## Regenerar

```
pip install pillow numpy
python3 source/build.py
```

Los colores y dibujos están en `build.py` (los sprites hechos a mano son texto ASCII, fáciles de retocar).
