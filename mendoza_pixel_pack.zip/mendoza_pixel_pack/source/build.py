#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MENDOZA INVADIDA - pack de sprites pixel art (original).
Genera todo el pack con:  python3 build.py
Requiere: Pillow y numpy.
"""
import json
import math
import os
import random
import zipfile

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageOps

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.abspath(os.path.join(HERE, ".."))

# --------------------------------------------------------------------------
# PALETA (40 colores). Las letras se usan en los dibujos ASCII.
# --------------------------------------------------------------------------
PAL = {
    # neutros
    "k": "#1a1423", "w": "#f4f1ea", "g": "#b8b4c4", "G": "#6b6580",
    # piel, paja, poncho, jean, cuero
    "s": "#e8b48a", "S": "#b97a56",
    "y": "#e6c25a", "Y": "#b8903a",
    "r": "#c8423c", "R": "#8a2a2e", "o": "#e8923a",
    "b": "#3f5fa8", "B": "#2a3c70",
    "n": "#8a5a3a", "N": "#5a3a28",
    # malbec y vegetacion
    "p": "#7a3a7e", "P": "#4a2253",
    "l": "#6fb04a", "L": "#3f7a3a", "D": "#264f33",
    # invasores (verde acido y magenta)
    "a": "#8cf07a", "A": "#3fb36a",
    "m": "#e05cc8", "M": "#9c3a96",
    "e": "#fff06a",
    # agua de acequia
    "c": "#5cc8e8", "C": "#2f86c0",
    # adobe, teja, asfalto
    "t": "#d9a066", "T": "#a8693f",
    "q": "#c4683c", "Q": "#8f4426",
    "h": "#4a4658", "H": "#332f42",
    # cielo y cordillera
    "i": "#1b1238", "I": "#2c1a55", "j": "#4a2a74", "u": "#b5476f",
    "v": "#5b5496", "V": "#454683", "x": "#a06fa8",
    "f": "#3a2a63", "F": "#2e2150",
}


def hexrgb(h):
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16))


def rgba(ch, a=255):
    return hexrgb(PAL[ch]) + (a,)


def new(w, h):
    return Image.new("RGBA", (w, h), (0, 0, 0, 0))


def put(img, x, y, ch):
    if 0 <= x < img.width and 0 <= y < img.height:
        img.putpixel((x, y), rgba(ch))


def from_ascii(name, rows):
    w = len(rows[0])
    img = new(w, len(rows))
    for y, row in enumerate(rows):
        if len(row) != w:
            raise ValueError("%s: la fila %d mide %d y se esperaba %d -> %r"
                             % (name, y, len(row), w, row))
        for x, ch in enumerate(row):
            if ch == ".":
                continue
            if ch not in PAL:
                raise ValueError("%s: letra desconocida %r en fila %d" % (name, ch, y))
            img.putpixel((x, y), rgba(ch))
    return img


def stamp(img, rows, x0, y0):
    for dy, row in enumerate(rows):
        for dx, ch in enumerate(row):
            if ch != ".":
                put(img, x0 + dx, y0 + dy, ch)


def patch(rows, edits):
    g = [list(r) for r in rows]
    for x, y, ch in edits:
        g[y][x] = ch
    return ["".join(r) for r in g]


def remap(rows, m):
    return ["".join(m.get(c, c) for c in r) for r in rows]


def outline(img, ch="k"):
    """Agrega 1px de contorno oscuro alrededor (la imagen crece 2px por lado)."""
    w, h = img.size
    big = new(w + 2, h + 2)
    big.paste(img, (1, 1))
    src = big.copy().load()
    po = big.load()
    for y in range(h + 2):
        for x in range(w + 2):
            if src[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < w + 2 and 0 <= ny < h + 2 and src[nx, ny][3] > 0:
                        po[x, y] = rgba(ch)
                        break
    return big


def flash(img):
    """Silueta blanca para el frame de golpe."""
    out = img.copy()
    px = out.load()
    for y in range(out.height):
        for x in range(out.width):
            if px[x, y][3] > 0:
                px[x, y] = rgba("w")
    return out


def tint(img, color_hex, amt):
    out = img.copy()
    px = out.load()
    tr, tg, tb = hexrgb(color_hex)
    for y in range(out.height):
        for x in range(out.width):
            r, g, b, a = px[x, y]
            if a:
                px[x, y] = (int(r + (tr - r) * amt), int(g + (tg - g) * amt),
                            int(b + (tb - b) * amt), a)
    return out


BAYER = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) / 16.0 + 1 / 32.0

# --------------------------------------------------------------------------
# PERSONAJES (dibujados a mano)
# --------------------------------------------------------------------------
PLAYER_BODY = [
    "................",
    ".....kkkkkk.....",
    "....kyyyyyyk....",
    "....kyyrrYyk....",
    "..kkkkkkkkkkkk..",
    ".kyyyyyyyyyyyyk.",
    "..kkYYYYYYYYkk..",
    "....ksssssSk....",
    "....ksssksSk....",
    "....kssssssk....",
    ".....kSSSSk.....",
    "...kkrrrrrrkk...",
    "..krrrRrrrrrk...",
    ".krrrRrrrrrrrk..",
    ".krrooorrooorrk.",
    ".krrrRrrrrrrrk..",
    "..kRRRRRRRRRk...",
]
LEGS_IDLE = [
    "...kbbbbbbbk....",
    "...kbbBBbbbk....",
    "...kbbk.kbbk....",
    "...kbbk.kbbk....",
    "...kbbk.kbbk....",
    "..knnnk.knnnk...",
    "..kkkkk.kkkkk...",
]
LEGS_W1 = [
    "...kbbbbbbbk....",
    "...kbbBBbbbk....",
    "..kbbk...kbbk...",
    ".kbbk.....kbbk..",
    ".kbbk......kbbk.",
    "knnnk.......knnk",
    "kkkkk.......kkkk",
]
LEGS_W2 = [
    "...kbbbbbbbk....",
    "...kbbBBbbbk....",
    "....kbbbbbk.....",
    "....kbbbbbk.....",
    "....kbbbbbk.....",
    "...knnnnnnk.....",
    "...kkkkkkkk.....",
]

# brazo estirado (pose de disparo con el sifon)
SHOOT_ARM = [
    (12, 12, "s"), (13, 12, "s"), (14, 12, "g"), (15, 12, "g"),
    (13, 11, "k"), (14, 11, "k"), (15, 11, "k"),
    (14, 13, "k"), (15, 13, "k"),
]

# invasor 1: "Bicho Baboso" (es un bicho? es un alien? nadie sabe)
SLIME_A = [
    "....m......m....",
    ".....k....k.....",
    ".....kkkkkk.....",
    "...kkaaaaaakk...",
    "..kaaaaaaaaaak..",
    ".kaawwaaaawwaak.",
    ".kaawkaaaawkaak.",
    ".kaaaaaaaaaaaak.",
    ".kaAaaaaaaaaaAk.",
    ".kAaaAAkkkkAAak.",
    ".kAAAAAAAAAAAAk.",
    "..kAAAAAAAAAAk..",
    ".kAAkAAAkAAAkAAk",
    ".kkkkkkkkkkkkkk.",
    "................",
    "................",
]

# invasor 3: "Ojo Flotante" (ovni? ojo gigante? si)
OJO_A = [
    "................",
    ".....kkkkkk.....",
    "...kkMMMMMMkk...",
    "..kMMmmmmmmMMk..",
    ".kMmwwwwwwwwmMk.",
    ".kMwweekkeewwMk.",
    ".kMwweekkeewwMk.",
    ".kMmwwwwwwwwmMk.",
    "..kMMmmmmmmMMk..",
    "...kkMMMMMMkk...",
    "..kmkMkMMkMkmk..",
    "..kmk.kMMk.kmk..",
    ".kmk..kMMk..kmk.",
    ".km...kmmk...mk.",
    "................",
    "................",
]
OJO_B = OJO_A[:10] + [
    "..kmkMkMMkMkmk..",
    "...kmkkMMkkmk...",
    "..kmk.kMMk.kmk..",
    "..km..kmmk..mk..",
    "................",
    "................",
]

# items
BOTTLE = [
    "................",
    "......kkkk......",
    "......kRRk......",
    "......kRRk......",
    "......kDLk......",
    "......kDLk......",
    ".....kkDLkk.....",
    "....kDDDLDDk....",
    "....kDDDLDDk....",
    "....kwwwwwwk....",
    "....kwppppwk....",
    "....kwwwwwwk....",
    "....kDDDLDDk....",
    "....kDDDLDDk....",
    "....kkkkkkkk....",
    "................",
]
EMPANADA = [
    "................", "................", "................",
    "................", "................",
    ".....kkkkkk.....",
    "...kkyyyyyTkk...",
    "..ktttttttttTk..",
    ".ktttttttttttTk.",
    ".kTtTtTtTtTtTtk.",
    ".kkkkkkkkkkkkkk.",
    "................", "................", "................",
    "................", "................",
]
MATE = [
    "................",
    "..........kgk...",
    ".........kgk....",
    "........kgk.....",
    "....kkkkgkkk....",
    "...kLLLgLLLLk...",
    "...kkLLLLLLkk...",
    "..knnnnnnnnnnk..",
    "..knnnnnnnnnNk..",
    "..knnYYnnnnnNk..",
    "..knnYYnnnnnNk..",
    "..knnnnnnnnNNk..",
    "...knnnnnnNNk...",
    "....kknnNNkk....",
    ".....kkkkkk.....",
    "................",
]
SIFON = [
    "........kk......",
    ".......kgk......",
    "....kkkgggkk....",
    "...kgggggggwk...",
    "...kkkkkkkkkk...",
    "....kccccCk.....",
    "...kcwccccCk....",
    "..kcwccccccCk...",
    "..kcwcccccccCk..",
    "..kccccccccCCk..",
    "..kccccccccCCk..",
    "..kccccccccCCk..",
    "..kcccccccCCCk..",
    "...kCCCCCCCCk...",
    "....kkkkkkkk....",
    "................",
]
SPRAY_A = [
    "........",
    "..cccc..",
    ".cwcccC.",
    "cccccCC.",
    ".cccCCC.",
    "..cCCC..",
    "........",
    "........",
]
SPRAY_B = [
    "........",
    ".c.ccc..",
    "..cwccc.",
    ".cccccCC",
    "..ccCCC.",
    ".c.CCC.c",
    "........",
    "........",
]
HEART = [
    "........",
    ".kk..kk.",
    "kwrkkrrk",
    "krrrrrrk",
    "krrrrRrk",
    ".krrrRk.",
    "..krRk..",
    "...kk...",
]
GRAPE_STAMP = [".kk.", "kmpk", "kpPk", ".kk."]
UFO_SMALL = [
    "....kkkkk....",
    "...kAaaAk....",
    "..kkkkkkkkk..",
    ".kPPePPePPek.",
    "..kkkPPPkkk..",
    "....k...k....",
]


def make_grape():
    img = new(16, 16)
    for (x, y) in [(6, 12), (5, 9), (8, 9), (3, 6), (6, 6), (9, 6),
                   (2, 3), (5, 3), (8, 3), (11, 3)]:
        stamp(img, GRAPE_STAMP, x, y)
    for (x, y, c) in [(7, 1, "N"), (8, 1, "N"), (7, 2, "N"), (8, 2, "N"),
                      (9, 1, "l"), (10, 0, "l"), (10, 1, "l"), (11, 1, "L"),
                      (10, 2, "L"), (9, 2, "L")]:
        put(img, x, y, c)
    return img


# --------------------------------------------------------------------------
# TILES Y PROPS (procedurales, con semilla fija => siempre salen igual)
# --------------------------------------------------------------------------
def tile_ground_top(seed=1):
    rng = random.Random(seed)
    img = new(16, 16)
    for y in range(16):
        for x in range(16):
            r = rng.random()
            ch = "T"
            if r < 0.16:
                ch = "t"
            elif r < 0.24:
                ch = "N"
            put(img, x, y, ch)
    for x in range(16):
        top = rng.choice([0, 1, 1, 2])
        for y in range(top, 4):
            ch = "l" if y == top else ("L" if y < 3 else "D")
            put(img, x, y, ch)
    return img


def tile_dirt(seed=2):
    rng = random.Random(seed)
    img = new(16, 16)
    for y in range(16):
        for x in range(16):
            r = rng.random()
            ch = "T"
            if r < 0.14:
                ch = "t"
            elif r < 0.22:
                ch = "N"
            put(img, x, y, ch)
    for _ in range(4):
        x, y = rng.randrange(1, 14), rng.randrange(1, 14)
        put(img, x, y, "g")
        put(img, x + 1, y, "G")
    return img


def tile_adobe(seed=3):
    rng = random.Random(seed)
    img = new(16, 16)
    for y in range(16):
        for x in range(16):
            r = rng.random()
            put(img, x, y, "T" if r < 0.1 else ("y" if r < 0.13 else "t"))
    for row in range(4):
        y0 = row * 4 + 3
        for x in range(16):
            put(img, x, y0, "T")
        off = 0 if row % 2 == 0 else 4
        for k in range(2):
            xv = (off + k * 8) % 16
            for y in range(row * 4, row * 4 + 3):
                put(img, xv, y, "T")
    for x in range(16):
        put(img, x, 0, "y") if rng.random() < 0.5 else None
    return img


def tile_roof():
    img = new(16, 16)
    for y in range(16):
        r, yy = divmod(y, 4)
        off = 4 if r % 2 else 0
        for x in range(16):
            xx = (x + off) % 8
            ch = "q"
            if yy == 3:
                ch = "Q"
            elif xx in (0, 7) and yy >= 1:
                ch = "Q"
            elif xx in (2, 3) and yy == 0:
                ch = "o"
            put(img, x, y, ch)
    return img


def tile_water(f):
    img = new(16, 16)
    for y in range(16):
        for x in range(16):
            put(img, x, y, "C")
    for yy in (3, 8, 13):
        for x in range(16):
            if ((x + f * 4 + yy) % 8) < 3:
                put(img, x, yy, "c")
    for x in range(16):
        put(img, x, 0, "c")
    put(img, (f * 3 + 2) % 16, 5, "w")
    put(img, (14 - f * 3) % 16, 10, "w")
    return img


def tile_rock(seed=5):
    rng = random.Random(seed)
    img = new(16, 16)
    for y in range(16):
        for x in range(16):
            put(img, x, y, "G")
    for _ in range(9):
        x, y = rng.randrange(0, 14), rng.randrange(0, 14)
        for dx in range(rng.randint(2, 4)):
            for dy in range(rng.randint(1, 2)):
                put(img, x + dx, y + dy, "g")
    for _ in range(4):
        x, y = rng.randrange(1, 15), rng.randrange(1, 12)
        for k in range(rng.randint(2, 4)):
            put(img, x + (k % 2), y + k, "k")
    return img


def tile_rock_snow(seed=6):
    img = tile_rock(seed)
    rng = random.Random(seed)
    for x in range(16):
        d = rng.choice([4, 5, 5, 6])
        for y in range(d):
            put(img, x, y, "w" if y < d - 1 else "g")
    return img


def tile_road(seed=7):
    rng = random.Random(seed)
    img = new(16, 16)
    for y in range(16):
        for x in range(16):
            r = rng.random()
            put(img, x, y, "H" if r < 0.1 else ("G" if r < 0.16 else "h"))
    for x in range(2, 14):
        put(img, x, 7, "y")
        put(img, x, 8, "Y")
    return img


def make_vine(seed=8):
    rng = random.Random(seed)
    img = new(16, 16)
    for y in range(11):
        for x in range(16):
            d = math.hypot((x - 7.5) / 8.5, (y - 4.5) / 6.0)
            if d + rng.uniform(-0.15, 0.15) < 1.0:
                r = rng.random()
                put(img, x, y, "l" if r < 0.2 else ("L" if r < 0.7 else "D"))
    for (x, y) in [(2, 8), (6, 9), (10, 8), (4, 11), (8, 12)]:
        stamp(img, GRAPE_STAMP, x, y)
    return img


def make_poplar(seed=3):
    rng = random.Random(seed)
    w, h = 14, 46
    img = new(w, h)
    fol_h = h - 6
    for y in range(fol_h):
        u = (y + 0.5) / fol_h
        hw = 6.6 * (math.sin(math.pi * u ** 0.72)) ** 0.55
        for x in range(w):
            c = (w - 1) / 2
            if abs(x - c) <= hw:
                rel = (x - c) / 6.5
                t = 0.5 + 0.5 * rel + rng.uniform(-0.35, 0.35) - 0.15 * (1 - u)
                if t < 0.06 and rng.random() < 0.4:
                    ch = "a"
                elif t < 0.28:
                    ch = "l"
                elif t < 0.62:
                    ch = "L"
                else:
                    ch = "D"
                put(img, x, y, ch)
    for y in range(fol_h - 1, h):
        put(img, 6, y, "n")
        put(img, 7, y, "N")
    return outline(img)


def make_barrel():
    w, h = 12, 14
    img = new(w, h)
    for y in range(h):
        u = (y + 0.5) / h
        hw = 5.0 + 1.0 * math.sin(math.pi * u)
        for x in range(w):
            if abs(x - 5.5) <= hw:
                ch = "n"
                if x % 3 == 0:
                    ch = "N"
                if x in (2, 3):
                    ch = "Y" if y % 2 else "n"
                put(img, x, y, ch)
    for yy in (2, 3, 10, 11):
        for x in range(w):
            if img.getpixel((x, yy))[3]:
                put(img, x, yy, "g" if (yy in (2, 10) and x < 6) else "G")
    for x in range(w):
        if img.getpixel((x, 0))[3]:
            put(img, x, 0, "T")
    return outline(img)


def make_house():
    rng = random.Random(11)
    w, h = 46, 38
    img = new(w, h)
    wall = new(40, 24)
    for ty in range(2):
        for tx in range(3):
            wall.paste(tile_adobe(20 + tx + ty * 3), (tx * 16, ty * 16))
    img.paste(wall.crop((0, 0, 40, 24)), (3, 14))
    d = ImageDraw.Draw(img)
    d.polygon([(0, 15), (8, 3), (37, 3), (45, 15)], fill=rgba("q"))
    for x in range(0, w):
        if x % 4 == 0:
            for y in range(3, 15):
                if img.getpixel((x, y))[3] and img.getpixel((x, y)) == rgba("q"):
                    put(img, x, y, "Q")
    for x in range(1, 45):
        put(img, x, 15, "Q")
        put(img, x, 16, "T")
    for x in range(10, 36):
        put(img, x, 3, "o")
    d.rectangle([19, 24, 26, 37], fill=rgba("N"))
    for y in range(24, 38):
        put(img, 22, y, "n")
    put(img, 25, 31, "y")
    for (x0, x1) in ((8, 14), (31, 37)):
        d.rectangle([x0, 22, x1, 29], fill=rgba("C"), outline=rgba("N"))
        for y in range(22, 30):
            put(img, (x0 + x1) // 2, y, "N")
        for x in range(x0, x1 + 1):
            put(img, x, 25, "N")
        put(img, x0 + 1, 23, "w")
        for x in range(x0 - 1, x1 + 2):
            put(img, x, 30, "T")
    return outline(img)


def make_ente(frame):
    """Jefe: mitad ovni, mitad monstruo. Nadie sabe que es."""
    w = h = 30
    img = new(w, h)
    for i in range(6):
        x0 = 4 + i * 4.4
        for y in range(18, 30):
            x = x0 + 2.2 * math.sin(y * 0.55 + i * 1.1 + frame * math.pi)
            xi = int(round(x))
            put(img, xi, y, "m")
            put(img, xi + 1, y, "M")
    d = ImageDraw.Draw(img)
    d.ellipse([0, 10, 29, 23], fill=rgba("M"), outline=rgba("k"))
    d.arc([2, 11, 27, 22], 200, 340, fill=rgba("m"))
    d.ellipse([7, 0, 22, 14], fill=rgba("A"), outline=rgba("k"))
    d.ellipse([9, 2, 13, 6], fill=rgba("a"))
    d.ellipse([11, 4, 18, 11], fill=rgba("w"), outline=rgba("k"))
    d.ellipse([13, 5, 16, 10], fill=rgba("e"))
    d.rectangle([14, 6, 15, 9], fill=rgba("k"))
    d.rectangle([4, 15, 25, 19], fill=rgba("k"))
    for x in range(5, 24, 4):
        for (dx, dy) in ((0, 15), (1, 15), (2, 15), (1, 16)):
            put(img, x + dx, dy, "w")
    for x in range(7, 24, 4):
        for (dx, dy) in ((0, 19), (1, 19), (2, 19), (1, 18)):
            put(img, x + dx, dy, "w")
    for (x, y) in ((4, 13), (9, 12), (20, 12), (25, 13)):
        put(img, x, y, "e")
    return outline(img)


def make_boom(frame):
    rng = random.Random(100 + frame)
    img = new(16, 16)
    cols = {0: ("e", "o", "r"), 1: ("e", "o", "r"), 2: ("o", "r", "R"), 3: ("g", "G", "H")}[frame]
    R = [4, 7, 8, 7][frame]
    for y in range(16):
        for x in range(16):
            d = math.hypot(x - 7.5, y - 7.5) + rng.uniform(-1.3, 1.3)
            if frame == 3 and rng.random() < 0.45:
                continue
            if d < R * 0.45:
                ch = cols[0]
            elif d < R * 0.75:
                ch = cols[1]
            elif d < R:
                ch = cols[2]
            else:
                continue
            put(img, x, y, ch)
    return img


# --------------------------------------------------------------------------
# FONDOS PARALLAX (320x176, se repiten en horizontal)
# --------------------------------------------------------------------------
W, H = 320, 176


def make_sky(seed=7):
    rng = random.Random(seed)
    ramp = [PAL[k] for k in ("i", "I", "j", "p", "u", "o")]
    n = len(ramp)
    img = Image.new("RGBA", (W, H))
    px = img.load()
    for y in range(H):
        t = min(1.0, y / (H * 0.72)) * (n - 1)
        i = min(int(t), n - 2)
        f = t - i
        for x in range(W):
            hx = ramp[i + 1] if BAYER[y % 4, x % 4] < f else ramp[i]
            px[x, y] = hexrgb(hx) + (255,)
    for _ in range(70):
        put(img, rng.randrange(W), rng.randrange(0, 60), rng.choice(["w", "w", "g", "e"]))
    # el portal de la invasion
    cx, cy, R = 236, 58, 30
    ramp2 = ["k", "P", "M", "m", "A", "a", "e"]
    for y in range(cy - R - 12, cy + R + 12):
        for x in range(cx - R - 12, cx + R + 12):
            if not (0 <= x < W and 0 <= y < H):
                continue
            dx, dy = x - cx, y - cy
            d = math.hypot(dx, dy)
            ang = math.atan2(dy, dx)
            if d <= R:
                t = min(1.0, max(0.0, d / R + 0.12 * math.sin(ang * 3 + d * 0.35)))
                v = (1 - t) * (len(ramp2) - 1)
                i = min(int(v), len(ramp2) - 2)
                f = v - i
                put(img, x, y, ramp2[i + 1] if BAYER[y % 4, x % 4] < f else ramp2[i])
            elif d < R + 10:
                if BAYER[y % 4, x % 4] < (1 - (d - R) / 10.0) * 0.5:
                    put(img, x, y, "M")
    for (ux, uy) in ((40, 30), (96, 54), (150, 20), (24, 78)):
        stamp(img, UFO_SMALL, ux, uy)
    return img


def ridge(base, amps, freqs, phases, ridged=True):
    ys = []
    for x in range(W):
        v = 0.0
        for a, f, ph in zip(amps, freqs, phases):
            s = math.sin(2 * math.pi * f * x / W + ph)
            v += a * ((1 - abs(s)) if ridged else s)
        ys.append(base - v)
    return ys


def make_andes():
    img = new(W, H)
    ys = ridge(100, [22, 14, 9, 6, 4], [2, 3, 5, 9, 16], [0.4, 1.9, 0.7, 2.6, 1.1])
    snow_line = 74
    jit = [int(round(2.2 * math.sin(2 * math.pi * 41 * x / W) + 1.6 * math.sin(2 * math.pi * 97 * x / W + 1)))
           for x in range(W)]
    rock_lit = [PAL["v"], PAL["x"]]
    rock_shade = [PAL["V"], PAL["v"]]
    px = img.load()
    for x in range(W):
        top = int(round(ys[x]))
        slope = ys[(x + 1) % W] - ys[x]
        shade = slope > 0
        for y in range(max(0, top), H):
            if y < snow_line + jit[x]:
                ch = PAL["g"] if shade else PAL["w"]
                px[x, y] = hexrgb(ch) + (255,)
                continue
            f = min(1.0, max(0.0, (y - snow_line) / 50.0))
            pair = rock_shade if shade else rock_lit
            hx = pair[1] if BAYER[y % 4, x % 4] < f else pair[0]
            px[x, y] = hexrgb(hx) + (255,)
    return img


def make_hills(seed=9):
    rng = random.Random(seed)
    img = new(W, H)
    ys = ridge(120, [10, 6, 4], [3, 6, 11], [1.3, 0.2, 2.2], ridged=False)
    px = img.load()
    for x in range(W):
        top = int(round(ys[x]))
        slope = ys[(x + 1) % W] - ys[x]
        for y in range(max(0, top), H):
            ch = "F" if slope > 0.2 else "f"
            if (y - top) < 2 and slope <= 0.2:
                ch = "V"
            px[x, y] = rgba(ch)
    for _ in range(140):
        x = rng.randrange(W)
        top = int(round(ys[x]))
        y = top + rng.randrange(3, 30)
        if y < H:
            put(img, x, y, "F")
    return img


def make_vineyard(poplar):
    rng = random.Random(12)
    img = new(W, H)
    px = img.load()
    for y in range(116, H):
        for x in range(W):
            px[x, y] = rgba("N") if (BAYER[y % 4, x % 4] < 0.55) else rgba("n")
    rows = [(124, 5), (131, 6), (139, 8)]
    # alamos lejanos detras de las vides
    far = tint(poplar, PAL["F"], 0.55)
    for tx in (24, 76, 148, 204, 268):
        img.alpha_composite(far, (tx, 128 - far.height + 2))
    for base, rh in rows:
        for x in range(W):
            top = base - rh + int(round(1.4 * math.sin(2 * math.pi * 48 * x / W + base))) + rng.choice([0, 0, 1])
            for y in range(top, base + 1):
                r = rng.random()
                if y - top < 2:
                    ch = "L" if r < 0.7 else "l"
                else:
                    ch = "D" if r < 0.85 else "L"
                if y > base - 3 and r > 0.9:
                    ch = "P"
                put(img, x, y, ch)
        for x in range(4, W, 24):
            for y in range(base - rh - 3, base + 1):
                put(img, x, y, "N")
            put(img, x, base - rh - 3, "k")
    return img


# --------------------------------------------------------------------------
# ARMADO DEL PACK
# --------------------------------------------------------------------------
def build_sprites():
    S = []            # (categoria, nombre, imagen)
    ANIM = {}

    def add(cat, name, img):
        S.append((cat, name, img))
        return img

    # --- heroe y vecino ---
    p_idle = PLAYER_BODY + LEGS_IDLE
    p_w1 = PLAYER_BODY + LEGS_W1
    p_w2 = PLAYER_BODY + LEGS_W2
    add("personajes", "player_idle", from_ascii("player_idle", p_idle))
    add("personajes", "player_walk_1", from_ascii("player_walk_1", p_w1))
    add("personajes", "player_walk_2", from_ascii("player_walk_2", p_w2))
    add("personajes", "player_shoot", from_ascii("player_shoot", patch(p_idle, SHOOT_ARM)))
    add("personajes", "player_hit", flash(S[0][2]))
    v_map = {"r": "b", "R": "B", "o": "y", "y": "t", "Y": "T", "b": "N", "B": "k"}
    for nm, rows in (("idle", p_idle), ("walk_1", p_w1), ("walk_2", p_w2)):
        add("personajes", "vecino_" + nm, from_ascii("vecino_" + nm, remap(rows, v_map)))
    ANIM["player_idle"] = {"frames": ["player_idle"], "fps": 1, "loop": True}
    ANIM["player_walk"] = {"frames": ["player_walk_1", "player_idle", "player_walk_2", "player_idle"],
                           "fps": 8, "loop": True}
    ANIM["vecino_walk"] = {"frames": ["vecino_walk_1", "vecino_idle", "vecino_walk_2", "vecino_idle"],
                           "fps": 6, "loop": True}

    # --- invasores ---
    sa = from_ascii("bicho_1", SLIME_A)
    sb_rows = ["................"] + SLIME_A[:-1]
    sb_rows = patch(sb_rows, [(4, 1, "e"), (11, 1, "e")])
    sb = from_ascii("bicho_2", sb_rows)
    add("invasores", "bicho_baboso_1", sa)
    add("invasores", "bicho_baboso_2", sb)
    add("invasores", "bicho_baboso_hit", flash(sa))
    ANIM["bicho_baboso"] = {"frames": ["bicho_baboso_1", "bicho_baboso_2"], "fps": 4, "loop": True}

    z_map = {"s": "l", "S": "L", "y": "Y", "Y": "N", "r": "n", "R": "N", "o": "Y",
             "b": "B", "B": "N", "n": "N"}
    z_arm = [(12, 12, "l"), (13, 12, "l"), (14, 12, "l"), (15, 12, "k"),
             (13, 11, "k"), (14, 11, "k"), (15, 11, "k"), (14, 13, "k"), (15, 13, "k"),
             (8, 8, "e"), (8, 9, "k"), (9, 9, "k"),
             (5, 16, "."), (8, 16, "."), (10, 16, ".")]
    zrows = [remap(PLAYER_BODY + legs, z_map) for legs in (LEGS_IDLE, LEGS_W1, LEGS_W2)]
    zrows = [patch(r, z_arm) for r in zrows]
    z0 = add("invasores", "zombi_vinatero_1", from_ascii("zombi_1", zrows[1]))
    add("invasores", "zombi_vinatero_2", from_ascii("zombi_2", zrows[0]))
    add("invasores", "zombi_vinatero_3", from_ascii("zombi_3", zrows[2]))
    add("invasores", "zombi_vinatero_hit", flash(z0))
    ANIM["zombi_vinatero"] = {"frames": ["zombi_vinatero_1", "zombi_vinatero_2",
                                         "zombi_vinatero_3", "zombi_vinatero_2"],
                              "fps": 5, "loop": True}

    o1 = from_ascii("ojo_1", OJO_A)
    o2 = from_ascii("ojo_2", OJO_B)
    add("invasores", "ojo_flotante_1", o1)
    add("invasores", "ojo_flotante_2", o2)
    add("invasores", "ojo_flotante_hit", flash(o1))
    ANIM["ojo_flotante"] = {"frames": ["ojo_flotante_1", "ojo_flotante_2"], "fps": 4, "loop": True}

    e1, e2 = make_ente(0), make_ente(1)
    add("invasores", "el_ente_1", e1)
    add("invasores", "el_ente_2", e2)
    add("invasores", "el_ente_hit", flash(e1))
    ANIM["el_ente"] = {"frames": ["el_ente_1", "el_ente_2"], "fps": 3, "loop": True}

    # --- items ---
    add("items", "item_uva", make_grape())
    add("items", "item_malbec", from_ascii("malbec", BOTTLE))
    add("items", "item_empanada", from_ascii("empanada", EMPANADA))
    add("items", "item_mate", from_ascii("mate", MATE))
    add("items", "item_sifon", from_ascii("sifon", SIFON))

    # --- efectos y UI ---
    add("efectos", "fx_chorro_1", from_ascii("chorro_1", SPRAY_A))
    add("efectos", "fx_chorro_2", from_ascii("chorro_2", SPRAY_B))
    ANIM["fx_chorro"] = {"frames": ["fx_chorro_1", "fx_chorro_2"], "fps": 10, "loop": True}
    for i in range(4):
        add("efectos", "fx_explosion_%d" % (i + 1), make_boom(i))
    ANIM["fx_explosion"] = {"frames": ["fx_explosion_%d" % (i + 1) for i in range(4)],
                            "fps": 12, "loop": False}
    add("ui", "ui_corazon", from_ascii("heart", HEART))
    add("ui", "ui_corazon_vacio", from_ascii("heart_e", remap(HEART, {"r": "g", "R": "G", "w": "w"})))

    # --- tiles ---
    add("tiles", "tile_suelo_pasto", tile_ground_top())
    add("tiles", "tile_tierra", tile_dirt())
    add("tiles", "tile_adobe", tile_adobe())
    add("tiles", "tile_teja", tile_roof())
    add("tiles", "tile_roca", tile_rock())
    add("tiles", "tile_roca_nieve", tile_rock_snow())
    add("tiles", "tile_ruta", tile_road())
    for i in range(4):
        add("tiles", "tile_acequia_%d" % (i + 1), tile_water(i))
    ANIM["tile_acequia"] = {"frames": ["tile_acequia_%d" % (i + 1) for i in range(4)],
                            "fps": 4, "loop": True}

    # --- props ---
    add("props", "prop_alamo", make_poplar())
    add("props", "prop_parra", make_vine())
    add("props", "prop_barril", make_barrel())
    add("props", "prop_casa_adobe", make_house())
    return S, ANIM


def pack_atlas(sprites, width=256):
    items = sorted(sprites, key=lambda t: (-t[2].height, -t[2].width, t[1]))
    x, y, rowh = 1, 1, 0
    pos = {}
    for cat, name, img in items:
        w, h = img.size
        if x + w + 1 > width:
            x = 1
            y += rowh + 1
            rowh = 0
        pos[name] = (x, y, w, h, cat)
        x += w + 1
        rowh = max(rowh, h)
    height = y + rowh + 1
    height = (height + 3) // 4 * 4
    sheet = new(width, height)
    imgs = {n: i for _, n, i in sprites}
    for name, (px_, py_, w, h, cat) in pos.items():
        sheet.paste(imgs[name], (px_, py_))
    return sheet, pos


def load_font(size):
    try:
        return ImageFont.load_default(size=size)
    except Exception:
        return ImageFont.load_default()


def contact_sheet(sprites, scale=4, width=1280):
    bg = (20, 16, 31, 255)
    card = (31, 26, 48, 255)
    font = load_font(12)
    big = load_font(18)
    cats = []
    for c, _, _ in sprites:
        if c not in cats:
            cats.append(c)
    titles = {"personajes": "PERSONAJES", "invasores": "INVASORES", "items": "ITEMS",
              "efectos": "EFECTOS", "ui": "UI", "tiles": "TILES", "props": "PROPS"}
    layout = []
    y = 14
    maxw = width
    for c in cats:
        layout.append(("title", titles.get(c, c.upper()), 14, y))
        y += 30
        x = 14
        rowh = 0
        for cc, name, img in sprites:
            if cc != c:
                continue
            sw, sh = img.width * scale, img.height * scale
            label_w = int(font.getlength(name)) if hasattr(font, "getlength") else len(name) * 7
            cw = max(sw, label_w) + 12
            if x + cw > width - 14:
                x = 14
                y += rowh + 8
                rowh = 0
            layout.append(("sprite", name, x, y, cw, sw, sh, img))
            x += cw + 8
            rowh = max(rowh, sh + 12 + 22)
        y += rowh + 20
    sheet = Image.new("RGBA", (maxw, y + 10), bg)
    d = ImageDraw.Draw(sheet)
    for item in layout:
        if item[0] == "title":
            d.text((item[2], item[3]), item[1], font=big, fill=(244, 241, 234, 255))
        else:
            _, name, x, yy, cw, sw, sh, img = item
            d.rectangle([x, yy, x + cw - 1, yy + sh + 12 + 20], fill=card)
            sheet.alpha_composite(img.resize((sw, sh), Image.NEAREST), (x + (cw - sw) // 2, yy + 6))
            d.text((x + 6, yy + sh + 12), name, font=font, fill=(184, 180, 196, 255))
    return sheet


def compose_scene(f, layers, S):
    img = Image.new("RGBA", (W, H))
    for layer in layers:
        img.alpha_composite(layer)
    gy = 144
    for tx in range(0, W, 16):
        if 12 <= tx // 16 <= 13:
            img.alpha_composite(S["tile_acequia_%d" % ((f // 2) % 4 + 1)], (tx, gy))
        else:
            img.alpha_composite(S["tile_suelo_pasto"], (tx, gy))
        img.alpha_composite(S["tile_tierra"], (tx, gy + 16))

    def on_ground(name, x, flip=False):
        im = S[name]
        if flip:
            im = ImageOps.mirror(im)
        img.alpha_composite(im, (x, gy - im.height))

    on_ground("prop_casa_adobe", 6)
    on_ground("prop_alamo", 62)
    on_ground("prop_barril", 98)
    # heroe disparando con el sifon
    pname = "player_shoot" if (f % 6) < 4 else ["player_walk_1", "player_idle", "player_walk_2"][f % 3]
    on_ground(pname, 124)
    sx = 140 + (f * 7) % 44
    img.alpha_composite(S["fx_chorro_%d" % (f % 2 + 1)], (sx, 128))
    # vecino asustado
    on_ground(["vecino_walk_1", "vecino_idle", "vecino_walk_2", "vecino_idle"][(f // 2) % 4], 80, False)
    # items flotando
    for i, nm in enumerate(("item_uva", "item_malbec", "item_empanada", "item_mate")):
        yb = 98 + int(round(2 * math.sin((f + i * 3) * 0.6)))
        img.alpha_composite(S[nm], (150 + i * 20, yb - 6 + (0 if i % 2 else 8)))
    # invasores
    zi = [1, 2, 3, 2][(f // 2) % 4]
    on_ground("zombi_vinatero_%d" % zi, 266 - (f * 2) % 24, flip=True)
    hop = abs(math.sin(f * 0.5)) * 8
    sl = S["bicho_baboso_%d" % (f % 2 + 1)]
    img.alpha_composite(sl, (236, int(gy - sl.height - hop)))
    oj = S["ojo_flotante_%d" % (f % 2 + 1)]
    img.alpha_composite(oj, (210, 70 + int(round(3 * math.sin(f * 0.7)))))
    en = S["el_ente_%d" % ((f // 2) % 2 + 1)]
    img.alpha_composite(en, (262, 34 + int(round(2 * math.sin(f * 0.5)))))
    img.alpha_composite(S["fx_explosion_%d" % ((f // 2) % 4 + 1)], (196, 118))
    # HUD
    for i in range(4):
        img.alpha_composite(S["ui_corazon" if i < 3 else "ui_corazon_vacio"], (8 + i * 10, 8))
    img.alpha_composite(S["item_uva"], (6, 20))
    return img


def write_palette(path_png, path_gpl, path_hex):
    keys = list(PAL.keys())
    cols = 10
    rows = (len(keys) + cols - 1) // cols
    img = Image.new("RGBA", (cols * 24, rows * 24), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for i, k in enumerate(keys):
        cx, cy = (i % cols) * 24, (i // cols) * 24
        d.rectangle([cx, cy, cx + 23, cy + 23], fill=rgba(k))
    img.save(path_png)
    with open(path_gpl, "w") as fh:
        fh.write("GIMP Palette\nName: Mendoza Invadida\nColumns: 10\n#\n")
        for k in keys:
            r, g, b = hexrgb(PAL[k])
            fh.write("%3d %3d %3d  %s\n" % (r, g, b, PAL[k]))
    with open(path_hex, "w") as fh:
        fh.write("\n".join(PAL[k][1:] for k in keys) + "\n")


def main():
    for sub in ("sprites", "backgrounds", "palette", "preview", "source"):
        os.makedirs(os.path.join(OUT, sub), exist_ok=True)

    S, ANIM = build_sprites()
    lookup = {n: i for _, n, i in S}

    # sprites sueltos (1x)
    for cat, name, img in S:
        d = os.path.join(OUT, "sprites", cat)
        os.makedirs(d, exist_ok=True)
        img.save(os.path.join(d, name + ".png"))

    # fondos
    sky = make_sky()
    andes = make_andes()
    hills = make_hills()
    vine = make_vineyard(lookup["prop_alamo"])
    layers = [sky, andes, hills, vine]
    for nm, im in zip(("fondo_1_cielo_portal", "fondo_2_andes", "fondo_3_sierras", "fondo_4_vinedo"), layers):
        im.save(os.path.join(OUT, "backgrounds", nm + ".png"))

    # spritesheet + atlas
    sheet, pos = pack_atlas(S)
    sheet.save(os.path.join(OUT, "spritesheet.png"))
    atlas = {
        "meta": {"image": "spritesheet.png", "size": {"w": sheet.width, "h": sheet.height},
                 "tile_size": 16, "scale_hint": "usar filtro NEAREST (sin suavizado)",
                 "background_size": {"w": W, "h": H}},
        "frames": {n: {"x": p[0], "y": p[1], "w": p[2], "h": p[3], "category": p[4]}
                   for n, p in sorted(pos.items())},
        "animations": ANIM,
    }
    with open(os.path.join(OUT, "atlas.json"), "w") as fh:
        json.dump(atlas, fh, indent=2, ensure_ascii=False)

    write_palette(os.path.join(OUT, "palette", "paleta.png"),
                  os.path.join(OUT, "palette", "mendoza_invadida.gpl"),
                  os.path.join(OUT, "palette", "mendoza_invadida.hex"))

    # vistas previas
    contact_sheet(S).save(os.path.join(OUT, "preview", "catalogo_x4.png"))
    scene = compose_scene(0, layers, lookup)
    scene.resize((W * 3, H * 3), Image.NEAREST).save(os.path.join(OUT, "preview", "escena_x3.png"))
    frames = []
    for f in range(12):
        fr = compose_scene(f, layers, lookup).convert("RGB").resize((W * 2, H * 2), Image.NEAREST)
        frames.append(fr.quantize(colors=128, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE))
    frames[0].save(os.path.join(OUT, "preview", "escena_animada.gif"), save_all=True,
                   append_images=frames[1:], duration=110, loop=0, disposal=2)

    print("sprites:", len(S), "| animaciones:", len(ANIM), "| atlas:", sheet.size)


if __name__ == "__main__":
    main()
